# RC Car Controller — Android App

A clean, single-screen Android app to control an Arduino RC car via HC-05 Bluetooth module using Classic Bluetooth SPP.

---

## 📁 Project Structure

```
RCCarController/
├── build.gradle                        ← Root project Gradle
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/
│   └── gradle-wrapper.properties
└── app/
    ├── build.gradle                    ← App-level Gradle
    └── src/main/
        ├── AndroidManifest.xml         ← Permissions & activity declaration
        ├── java/com/rccar/controller/
        │   └── MainActivity.java       ← All Bluetooth + UI logic
        └── res/
            ├── layout/
            │   └── activity_main.xml   ← Single-screen layout
            ├── values/
            │   ├── colors.xml
            │   ├── strings.xml
            │   └── themes.xml
            └── drawable/
                └── spinner_bg.xml
```

---

## 🔧 Commands Sent to HC-05

| Button         | Character Sent |
|----------------|---------------|
| Manual Mode    | `M`           |
| Auto Mode      | `A`           |
| Forward (hold) | `F`           |
| Backward (hold)| `B`           |
| Left (hold)    | `L`           |
| Right (hold)   | `R`           |
| Stop           | `S`           |

Movement buttons send their direction on **press** and `S` on **release**.

---

## 🛠 Build Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK API 23+ (minSdk 23, targetSdk 34)
- JDK 17 (bundled with Android Studio)
- A physical Android device (Bluetooth doesn't work on emulator)

### Steps

#### 1. Open in Android Studio
- Launch Android Studio
- Choose **"Open"** → Select the `RCCarController/` folder
- Wait for Gradle sync to complete (may take 1–2 minutes first time)

#### 2. Build the APK
**Option A — Debug APK (recommended for testing):**
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
```
APK location: `app/build/outputs/apk/debug/app-debug.apk`

**Option B — via terminal:**
```bash
cd RCCarController
./gradlew assembleDebug
```

#### 3. Install on Device
- Enable **USB Debugging** on your phone: Settings → Developer Options → USB Debugging
- Connect via USB
- Click the **▶ Run** button in Android Studio, or:
```bash
./gradlew installDebug
```

---

## 📱 Using the App

### Step 1 — Pair HC-05 with your phone
1. Power on your Arduino car (HC-05 LED will blink rapidly)
2. Open Android **Settings → Bluetooth**
3. Scan for devices → tap **HC-05**
4. Enter PIN: `1234` (default) or `0000`
5. HC-05 is now paired ✓

### Step 2 — Connect in the app
1. Open **RC Car Controller**
2. Grant Bluetooth permissions when prompted
3. Select **HC-05** from the dropdown (tap ↻ to refresh if not visible)
4. Tap **Connect**
5. Status changes to **● Connected** (green)

### Step 3 — Control
- Tap **Manual** mode to enable Bluetooth control
- Use the **▲ ▼ ◀ ▶** buttons — hold to move, release to stop
- Tap ■ for immediate stop
- Tap **Auto** to let the Arduino's ultrasonic sensor take over

---

## ⚡ Arduino Serial Code Example

Your Arduino sketch should listen on the hardware serial (or SoftwareSerial on pins 0/1 for HC-05):

```cpp
#include <SoftwareSerial.h>
SoftwareSerial bt(10, 11); // RX, TX — adjust to your wiring

void setup() {
  bt.begin(9600);
  // motor pin setup here
}

void loop() {
  if (bt.available()) {
    char cmd = bt.read();
    switch (cmd) {
      case 'F': moveForward();  break;
      case 'B': moveBackward(); break;
      case 'L': turnLeft();     break;
      case 'R': turnRight();    break;
      case 'S': stopMotors();   break;
      case 'M': setManual();    break;
      case 'A': setAuto();      break;
    }
  }
  if (isAutoMode) { ultrasonicLogic(); }
}
```

---

## 🐛 Troubleshooting

| Problem | Fix |
|---------|-----|
| HC-05 not in list | Pair it first in Android Bluetooth settings |
| "Connection failed" | Check HC-05 is powered on; try re-pairing |
| Permission denied | Go to App Settings → grant Bluetooth permissions manually |
| Buttons don't respond | Make sure status shows **● Connected** first |
| App crashes on Android 12+ | Ensure BLUETOOTH_CONNECT permission granted |
| Spinner shows "No paired devices" | Tap ↻ refresh after pairing |

---

## 📋 Permissions Used

| Permission | Purpose | Android Version |
|------------|---------|----------------|
| `BLUETOOTH` | Basic BT operations | ≤ Android 11 |
| `BLUETOOTH_ADMIN` | Manage BT connections | ≤ Android 11 |
| `BLUETOOTH_CONNECT` | Connect to paired devices | Android 12+ |
| `BLUETOOTH_SCAN` | Scan for devices | Android 12+ |
| `ACCESS_FINE_LOCATION` | Required for BT scanning | ≤ Android 11 |

---

## 🎨 UI Notes

- Dark theme optimized for low-light use while driving the car
- Large touch targets (80dp height on movement buttons) for reliable input
- Status color: 🟢 Connected · 🟡 Connecting · 🔴 Disconnected
- Control buttons are disabled (dimmed to 40% opacity) until connected
