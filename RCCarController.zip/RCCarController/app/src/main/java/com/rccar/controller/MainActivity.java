package com.rccar.controller;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.rccar.controller.databinding.ActivityMainBinding;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    // SPP UUID — required for HC-05
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // Connection states
    private static final int STATE_NONE        = 0;
    private static final int STATE_CONNECTING  = 1;
    private static final int STATE_CONNECTED   = 2;
    private static final int STATE_DISCONNECTED = 3;

    private ActivityMainBinding binding;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;
    private ConnectThread connectThread;
    private int connectionState = STATE_NONE;

    private final List<BluetoothDevice> pairedDeviceList = new ArrayList<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Permission launcher for Android 12+
    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean allGranted = true;
                for (Boolean granted : result.values()) {
                    if (!granted) { allGranted = false; break; }
                }
                if (allGranted) {
                    loadPairedDevices();
                } else {
                    Toast.makeText(this, "Bluetooth permissions are required to use this app.", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "This device does not support Bluetooth.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        setupButtonListeners();
        checkPermissionsAndLoad();
        setControlsEnabled(false);
        updateStatus(STATE_NONE);
    }

    // ─── Permission Handling ───────────────────────────────────────────────────

    private void checkPermissionsAndLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+
            List<String> needed = new ArrayList<>();
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (!needed.isEmpty()) {
                permissionLauncher.launch(needed.toArray(new String[0]));
            } else {
                loadPairedDevices();
            }
        } else {
            // Android 6–11
            List<String> needed = new ArrayList<>();
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
            }
            if (!needed.isEmpty()) {
                permissionLauncher.launch(needed.toArray(new String[0]));
            } else {
                loadPairedDevices();
            }
        }
    }

    // ─── Paired Devices ────────────────────────────────────────────────────────

    private void loadPairedDevices() {
        pairedDeviceList.clear();
        Set<BluetoothDevice> bondedDevices;

        try {
            bondedDevices = bluetoothAdapter.getBondedDevices();
        } catch (SecurityException e) {
            Toast.makeText(this, "Permission denied when accessing paired devices.", Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> deviceNames = new ArrayList<>();
        if (bondedDevices != null) {
            for (BluetoothDevice device : bondedDevices) {
                pairedDeviceList.add(device);
                try {
                    String name = device.getName();
                    String addr = device.getAddress();
                    deviceNames.add((name != null ? name : "Unknown") + " [" + addr + "]");
                } catch (SecurityException e) {
                    deviceNames.add("Unknown Device");
                }
            }
        }

        if (deviceNames.isEmpty()) {
            deviceNames.add("No paired devices found");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, deviceNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerDevices.setAdapter(adapter);
    }

    // ─── Bluetooth Connection ──────────────────────────────────────────────────

    private void connectToDevice() {
        if (pairedDeviceList.isEmpty()) {
            Toast.makeText(this, "No paired devices. Pair HC-05 in Bluetooth settings first.", Toast.LENGTH_LONG).show();
            return;
        }

        int selectedPos = binding.spinnerDevices.getSelectedItemPosition();
        if (selectedPos < 0 || selectedPos >= pairedDeviceList.size()) {
            Toast.makeText(this, "Please select a device.", Toast.LENGTH_SHORT).show();
            return;
        }

        BluetoothDevice device = pairedDeviceList.get(selectedPos);

        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }

        connectThread = new ConnectThread(device);
        connectThread.start();
        updateStatus(STATE_CONNECTING);
        binding.btnConnect.setEnabled(false);
    }

    private void disconnect() {
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }
        bluetoothSocket = null;
        outputStream = null;
        updateStatus(STATE_DISCONNECTED);
        setControlsEnabled(false);
        binding.btnConnect.setEnabled(true);
        binding.btnConnect.setText("Connect");
    }

    // ─── Send Command ──────────────────────────────────────────────────────────

    private void sendCommand(String cmd) {
        if (outputStream == null || connectionState != STATE_CONNECTED) {
            Toast.makeText(this, "Not connected to any device.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            outputStream.write(cmd.getBytes());
            outputStream.flush();
        } catch (IOException e) {
            Toast.makeText(this, "Failed to send command. Connection lost.", Toast.LENGTH_SHORT).show();
            disconnect();
        }
    }

    // ─── UI Updates ───────────────────────────────────────────────────────────

    private void updateStatus(int state) {
        connectionState = state;
        switch (state) {
            case STATE_NONE:
                binding.tvStatus.setText("● Not connected");
                binding.tvStatus.setTextColor(getColor(R.color.status_disconnected));
                break;
            case STATE_CONNECTING:
                binding.tvStatus.setText("◌ Connecting...");
                binding.tvStatus.setTextColor(getColor(R.color.status_connecting));
                break;
            case STATE_CONNECTED:
                binding.tvStatus.setText("● Connected");
                binding.tvStatus.setTextColor(getColor(R.color.status_connected));
                break;
            case STATE_DISCONNECTED:
                binding.tvStatus.setText("● Disconnected");
                binding.tvStatus.setTextColor(getColor(R.color.status_disconnected));
                break;
        }
    }

    private void setControlsEnabled(boolean enabled) {
        binding.btnForward.setEnabled(enabled);
        binding.btnBackward.setEnabled(enabled);
        binding.btnLeft.setEnabled(enabled);
        binding.btnRight.setEnabled(enabled);
        binding.btnStop.setEnabled(enabled);
        binding.btnManual.setEnabled(enabled);
        binding.btnAuto.setEnabled(enabled);

        float alpha = enabled ? 1.0f : 0.4f;
        binding.btnForward.setAlpha(alpha);
        binding.btnBackward.setAlpha(alpha);
        binding.btnLeft.setAlpha(alpha);
        binding.btnRight.setAlpha(alpha);
        binding.btnStop.setAlpha(alpha);
        binding.btnManual.setAlpha(alpha);
        binding.btnAuto.setAlpha(alpha);
    }

    // ─── Button Listeners ─────────────────────────────────────────────────────

    private void setupButtonListeners() {
        // Connect / Disconnect button
        binding.btnConnect.setOnClickListener(v -> {
            if (connectionState == STATE_CONNECTED) {
                disconnect();
            } else {
                connectToDevice();
            }
        });

        // Mode buttons
        binding.btnManual.setOnClickListener(v -> {
            sendCommand("M");
            highlightModeButton(true);
            Toast.makeText(this, "Manual Mode: Bluetooth control", Toast.LENGTH_SHORT).show();
        });

        binding.btnAuto.setOnClickListener(v -> {
            sendCommand("A");
            highlightModeButton(false);
            Toast.makeText(this, "Auto Mode: Ultrasonic control", Toast.LENGTH_SHORT).show();
        });

        // Movement buttons — press sends direction, release sends Stop
        setupMovementButton(binding.btnForward, "F");
        setupMovementButton(binding.btnBackward, "B");
        setupMovementButton(binding.btnLeft, "L");
        setupMovementButton(binding.btnRight, "R");

        // Dedicated stop button
        binding.btnStop.setOnClickListener(v -> sendCommand("S"));

        // Refresh device list
        binding.btnRefresh.setOnClickListener(v -> {
            loadPairedDevices();
            Toast.makeText(this, "Device list refreshed", Toast.LENGTH_SHORT).show();
        });
    }

    private void setupMovementButton(View button, String command) {
        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setPressed(true);
                    sendCommand(command);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    sendCommand("S");
                    break;
            }
            return true;
        });
    }

    private void highlightModeButton(boolean isManual) {
        if (isManual) {
            binding.btnManual.setBackgroundTintList(getColorStateList(R.color.btn_mode_active));
            binding.btnAuto.setBackgroundTintList(getColorStateList(R.color.btn_mode_inactive));
        } else {
            binding.btnAuto.setBackgroundTintList(getColorStateList(R.color.btn_mode_active));
            binding.btnManual.setBackgroundTintList(getColorStateList(R.color.btn_mode_inactive));
        }
    }

    // ─── Connect Thread ───────────────────────────────────────────────────────

    private class ConnectThread extends Thread {
        private final BluetoothSocket socket;

        ConnectThread(BluetoothDevice device) {
            BluetoothSocket tmp = null;
            try {
                tmp = device.createRfcommSocketToServiceRecord(SPP_UUID);
            } catch (IOException | SecurityException e) {
                e.printStackTrace();
            }
            socket = tmp;
        }

        @Override
        public void run() {
            // Cancel discovery to speed up connection
            try {
                bluetoothAdapter.cancelDiscovery();
            } catch (SecurityException ignored) {}

            try {
                socket.connect();

                // Connected!
                bluetoothSocket = socket;
                outputStream = socket.getOutputStream();

                mainHandler.post(() -> {
                    updateStatus(STATE_CONNECTED);
                    setControlsEnabled(true);
                    binding.btnConnect.setEnabled(true);
                    binding.btnConnect.setText("Disconnect");
                    Toast.makeText(MainActivity.this, "Connected to HC-05!", Toast.LENGTH_SHORT).show();
                });

            } catch (IOException connectException) {
                // Failed to connect
                try { socket.close(); } catch (IOException ignored) {}

                mainHandler.post(() -> {
                    updateStatus(STATE_DISCONNECTED);
                    setControlsEnabled(false);
                    binding.btnConnect.setEnabled(true);
                    binding.btnConnect.setText("Connect");
                    Toast.makeText(MainActivity.this, "Connection failed. Make sure HC-05 is powered on.", Toast.LENGTH_LONG).show();
                });
            }
        }

        void cancel() {
            try { socket.close(); } catch (IOException ignored) {}
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnect();
    }
}
